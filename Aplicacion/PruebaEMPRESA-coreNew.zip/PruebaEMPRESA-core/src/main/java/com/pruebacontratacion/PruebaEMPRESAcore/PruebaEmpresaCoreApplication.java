package com.pruebacontratacion.PruebaEMPRESAcore;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PruebaEmpresaCoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(PruebaEmpresaCoreApplication.class, args);
	}

}
